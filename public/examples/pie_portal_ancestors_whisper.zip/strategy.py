"""
PIE Portal: The Ancestor's Whisper - Converted from legacy M5Stack format.
Trace the 'DNA' of language back 5,000 years! This game turns your DiceMaster into a linguistic time machine, showing how a single Proto-Indo-European (PIE) root evolved into common words across English, Latin, Greek, and Sanskrit.
"""
import os
import random

from dice import screen, motion, orientation, assets, log, timer
from dice.strategy import BaseStrategy


class PiePortalAncestorsWhisper(BaseStrategy):
    _strategy_name = "pie_portal_ancestors_whisper"

    def __init__(self, game_name: str, config: dict, assets_path: str, **kwargs):
        super().__init__(game_name, config, assets_path, **kwargs)
        self.top_screen_id = None
        self.bottom_screen_id = None
        self.side_screen_ids = []
        self.current_round = 0
        self.total_rounds = 10
        self.displayed_initial = False
        self.last_trigger_time = 0.0
        self.cooldown_duration = 3.0
        log(f"[PiePortalAncestorsWhisper] initialized with {self.total_rounds} rounds")

    def _on_orientation_change(self, top, bottom):
        self.top_screen_id = top
        self.bottom_screen_id = bottom
        self.side_screen_ids = [
            sid for sid in range(1, 7)
            if sid != top and sid != bottom
        ]
        if not self.displayed_initial:
            self._display_round()
            self.displayed_initial = True

    def _display_round(self):
        if self.top_screen_id is None:
            return
        r = self.current_round
        root = self._assets_path

        screen.set_text(self.top_screen_id, os.path.join(root, f"round_{r}_top.json"))
        screen.set_text(self.bottom_screen_id, os.path.join(root, f"round_{r}_bottom.json"))

        face_names = ["front", "back", "left", "right"]
        sides = self.side_screen_ids[:4]
        for i, sid in enumerate(sides):
            screen.set_text(sid, os.path.join(root, f"round_{r}_{face_names[i]}.json"))

        log(f"Displaying round {r}")

    def _on_shake(self, intensity):
        import time
        now = time.time()
        if now - self.last_trigger_time < self.cooldown_duration:
            return
        self.last_trigger_time = now
        self.current_round = random.randint(0, self.total_rounds - 1)
        self._display_round()

    def start_strategy(self):
        motion.on_shake(self._on_shake)
        orientation.on_change(self._on_orientation_change)
        log("[PiePortalAncestorsWhisper] started")

    def stop_strategy(self):
        log("[PiePortalAncestorsWhisper] stopped")
